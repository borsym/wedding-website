export const menuData = [
  { title: "About Us", link: "#about" },
  { title: "Home", link: "#homes" },
  { title: "Offers", link: "#offers" },
  /* { title: "Contact us", link: "#contact" }, */
];
